<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: login.php"); exit(); }
include 'db.php';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    $mysqli->query("INSERT INTO students (name,email,phone,course) VALUES ('$name','$email','$phone','$course')");
    header("Location: index.php");
    exit();
}
?>

<div class="container">
    <h2>Add Student</h2>
    <form method="post">
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone" required>
        <input type="text" name="course" placeholder="Course" required>
        <input type="submit" name="submit" value="Add Student">
    </form>
</div>
